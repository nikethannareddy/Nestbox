"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface User {
  id: string
  email: string
  full_name: string
  role: "guest" | "volunteer" | "sponsor" | "admin"
  phone?: string
  created_at: string
  updated_at: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<{ error?: string }>
  signup: (email: string, password: string, userData: any) => Promise<{ error?: string }>
  logout: () => Promise<void>
  updateUser: (updatedUser: Partial<User>) => Promise<{ error?: string }>
  isAuthenticated: boolean
  hasRole: (role: string | string[]) => boolean
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(false)

  const login = async (email: string, password: string) => {
    try {
      // Mock authentication - check for admin credentials
      if (email === "admin@nestbox.com" && password === "admin123") {
        const adminUser: User = {
          id: "admin-1",
          email: "admin@nestbox.com",
          full_name: "Admin User",
          role: "admin",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        setUser(adminUser)
        return {}
      }

      // Mock volunteer login
      const mockUser: User = {
        id: "volunteer-1",
        email: email,
        full_name: "Volunteer User",
        role: "volunteer",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      setUser(mockUser)
      return {}
    } catch (error) {
      return { error: "Login failed" }
    }
  }

  const signup = async (email: string, password: string, userData: any) => {
    try {
      const mockUser: User = {
        id: `user-${Date.now()}`,
        email: email,
        full_name: `${userData.firstName} ${userData.lastName}`,
        role: userData.role || "volunteer",
        phone: userData.phone,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      setUser(mockUser)
      return {}
    } catch (error) {
      return { error: "Signup failed" }
    }
  }

  const logout = async () => {
    setUser(null)
  }

  const updateUser = async (updatedUser: Partial<User>) => {
    if (!user) return { error: "No user logged in" }
    setUser({ ...user, ...updatedUser })
    return {}
  }

  const hasRole = (roles: string | string[]) => {
    if (!user) return false
    const roleArray = Array.isArray(roles) ? roles : [roles]
    return roleArray.includes(user.role)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        updateUser,
        isAuthenticated: !!user,
        hasRole,
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
