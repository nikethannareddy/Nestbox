"use client"

import { useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { AuthForms } from "@/components/auth/auth-forms"
import { useAuth } from "@/components/auth/auth-provider"

export default function AuthPage() {
  const { login, isAuthenticated, user } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const mode = searchParams.get("mode") // Check for signup mode

  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === "admin") {
        router.push("/admin")
      } else {
        router.push("/dashboard")
      }
    }
  }, [isAuthenticated, user, router])

  const handleAuthSuccess = (user: any) => {
    login(user)
    if (user.role === "admin") {
      router.push("/admin")
    } else {
      router.push("/dashboard")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="font-serif text-3xl font-bold text-foreground mb-2">Welcome to NestBox</h1>
          <p className="text-muted-foreground">Join our community of bird conservation enthusiasts</p>
        </div>

        <AuthForms onAuthSuccess={handleAuthSuccess} initialMode={mode} />

        <div className="mt-6 text-center">
          <a href="/" className="text-primary hover:text-primary/80 text-sm">
            ← Back to Home
          </a>
        </div>
      </div>
    </div>
  )
}
